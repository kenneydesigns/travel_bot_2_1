# 🎬 Sentiment Analyzer for Movie Reviews

This project is a beginner-friendly machine learning app that performs **sentiment analysis** on movie reviews using a pre-trained model from Hugging Face Transformers.

## 🚀 Project Overview

This tool takes in user-provided text (like a movie review) and uses a fine-tuned BERT model (`distilbert-base-uncased-finetuned-sst-2-english`) to classify the sentiment as **positive** or **negative**.

It's perfect for:
- Exploring NLP with minimal setup
- Understanding how transformer models work in production
- Deploying your first ML-powered web app using **Gradio**

## 🧰 Tech Stack

- Python
- [🤗 Transformers](https://huggingface.co/transformers/)
- [🤗 Datasets](https://huggingface.co/docs/datasets)
- [Gradio](https://gradio.app/) (for the UI)

## 🛠️ How to Run

1. Clone this repo:
    ```bash
    git clone https://github.com/yourusername/sentiment-analyzer
    cd sentiment-analyzer
    ```

2. Install dependencies:
    ```bash
    pip install transformers datasets gradio
    ```

3. Run the app:
    ```bash
    python app.py
    ```

4. Open your browser to view the app:
    ```
    http://127.0.0.1:7860
    ```

## 🧪 Example

Input:  
> "That movie had me hooked from start to finish!"

Output:  
> **Positive** (confidence: 0.998)

## 📦 Next Steps

- Add support for other text classification tasks
- Fine-tune your own sentiment model
- Deploy to Hugging Face Spaces

---

Made with 🤖 and 🎥 for fun and learning.
