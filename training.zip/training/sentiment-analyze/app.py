from transformers import pipeline
import gradio as gr

# Load the sentiment-analysis pipeline
classifier = pipeline("sentiment-analysis")

def analyze_sentiment(text):
    result = classifier(text)[0]
    label = result["label"]
    score = round(result["score"] * 100, 2)
    return f"{label} ({score}%)"

# Gradio interface
gr.Interface(
    fn=analyze_sentiment,
    inputs="text",
    outputs="text",
    title="🎬 Movie Review Sentiment Analyzer",
    description="Enter a movie review to determine if it's positive or negative!"
).launch()
