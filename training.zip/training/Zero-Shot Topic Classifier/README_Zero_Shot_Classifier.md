# 🧭 Zero-Shot Topic Classifier

This project demonstrates the power of **zero-shot learning** using Hugging Face Transformers. It classifies text into **custom user-defined categories** without needing any fine-tuning or labeled training data.

## 🚀 Project Overview

With this app, you can:
- Enter any piece of text (article, message, headline)
- Define the labels you'd like to classify it into (e.g., "sports", "politics", "technology")
- Let the model determine which label fits best using zero-shot classification

It’s powered by `facebook/bart-large-mnli`, a model trained on the MNLI dataset for natural language inference.

## 🧰 Tech Stack

- Python
- [🤗 Transformers](https://huggingface.co/transformers/)
- [Gradio](https://gradio.app/) (for interface)

## 🛠️ How to Run

1. Clone this repo:
    ```bash
    git clone https://github.com/yourusername/zero-shot-classifier
    cd zero-shot-classifier
    ```

2. Install dependencies:
    ```bash
    pip install transformers gradio
    ```

3. Launch the app:
    ```bash
    python app.py
    ```

4. Open your browser:
    ```
    http://127.0.0.1:7860
    ```

## 🔍 Example

**Text:**
> "Tesla's stock rose sharply after their quarterly earnings beat expectations."

**Candidate Labels:**
> "sports, finance, entertainment, technology"

**Prediction:**
> - finance (score: 0.96)
> - technology (score: 0.88)

## 💡 Future Enhancements

- Batch classify multiple texts at once
- Visualize label confidence scores as a bar chart
- Save results to CSV for analysis

---

Explore NLP without borders using zero-shot learning! 🧠🌐
