# ❓ Question Answering Assistant

This project is a simple, interactive **question answering (QA) app** powered by a Hugging Face transformer model. It takes a user-provided context (like an article or passage) and answers specific questions based on that context.

## 🚀 Project Overview

This tool is ideal for:
- Exploring how transformer models extract information from text
- Learning about extractive QA models like `distilbert-base-cased-distilled-squad`
- Building NLP applications that interact with user inputs

## 🧰 Tech Stack

- Python
- [🤗 Transformers](https://huggingface.co/transformers/)
- [Gradio](https://gradio.app/) (for interface)

## 🛠️ How to Run

1. Clone the repo:
    ```bash
    git clone https://github.com/yourusername/qa-assistant
    cd qa-assistant
    ```

2. Install dependencies:
    ```bash
    pip install transformers gradio
    ```

3. Run the app:
    ```bash
    python app.py
    ```

4. Open your browser:
    ```
    http://127.0.0.1:7860
    ```

## 🧪 Example

**Context:**
> "The Hugging Face Transformers library is an open-source library that provides general-purpose architectures for Natural Language Understanding and Natural Language Generation."

**Question:**
> "What does the Hugging Face Transformers library provide?"

**Answer:**
> "General-purpose architectures for Natural Language Understanding and Generation."

## 💡 Future Features

- PDF upload and question answering from documents
- Answer highlighting in the original text
- Support for multilingual QA models

---

Smart answers from smarter machines. 🔍🤖
