from transformers import pipeline
import gradio as gr

# Load the NER model pipeline
ner_pipeline = pipeline("ner", grouped_entities=True)

def extract_entities(text):
    entities = ner_pipeline(text)
    output = ""
    for ent in entities:
        word = ent["word"]
        label = ent["entity_group"]
        score = round(ent["score"] * 100, 2)
        output += f"{word} → {label} ({score}%)\\n"
    return output.strip()

# Gradio app
gr.Interface(
    fn=extract_entities,
    inputs="text",
    outputs="text",
    title="🧠 Named Entity Recognition (NER) Visualizer",
    description="Enter a sentence or paragraph, and see which named entities (like people, organizations, locations) are detected!"
).launch()
