# 🧠 Named Entity Recognition (NER) Visualizer

An interactive NLP tool that identifies and highlights **named entities** (like people, organizations, dates, locations, etc.) within a given text. This project uses a Hugging Face `ner` pipeline and Gradio to create a fun, visual experience for learning and experimenting with token classification.

## 🚀 Project Overview

This app allows you to paste any block of text and visually see the entities extracted by a pre-trained model. Entities are grouped and color-coded for easy interpretation.

Great for:
- Exploring token classification in NLP
- Visualizing model output in real time
- Learning how transformers handle entity detection

## 🧰 Tech Stack

- Python
- [🤗 Transformers](https://huggingface.co/transformers/)
- [Gradio](https://gradio.app/) (for deployment)

## 🛠️ How to Run

1. Clone this repository:
    ```bash
    git clone https://github.com/yourusername/ner-visualizer
    cd ner-visualizer
    ```

2. Install the requirements:
    ```bash
    pip install transformers gradio
    ```

3. Start the app:
    ```bash
    python app.py
    ```

4. Open your browser to:
    ```
    http://127.0.0.1:7860
    ```

## 🔍 Example

Input:
> "Barack Obama was born in Hawaii and served as President of the United States."

Output:
- **Barack Obama** → Person
- **Hawaii** → Location
- **President** → Title
- **United States** → Country

Entities are shown with highlights and labels directly in the interface.

## 💡 Bonus Ideas

- Add options to switch between different NER models
- Export highlighted text as HTML or Markdown
- Combine with translation or summarization for deeper workflows

---

Made to make NLP a little more visual and a lot more fun! 🎨🤖
