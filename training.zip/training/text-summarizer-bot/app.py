from transformers import pipeline
import gradio as gr

# Load summarization model pipeline
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

def summarize_text(text):
    # Limit input to 1024 tokens (~4000 characters)
    max_input_length = 4000
    text = text[:max_input_length]

    summary = summarizer(text, max_length=150, min_length=30, do_sample=False)
    return summary[0]['summary_text']

# Gradio interface
gr.Interface(
    fn=summarize_text,
    inputs="text",
    outputs="text",
    title="📄 Text Summarizer Bot",
    description="Paste in a long passage of text, and this bot will generate a short, concise summary."
).launch()
